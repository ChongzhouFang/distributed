---
name: "General question"
about: Questions related to Azure Functions and the host

---

#### Is your question related to a specific version? If so, please specify:

#### What language does your question apply to? (e.g. C#, JavaScript, Java, All) 

#### Question
